from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    generador = Node(
        package='challenge_1',
        executable='generador_senal',
        name='generador_senal'
    )

    procesador = Node(
        package='challenge_1',
        executable='procesador_senal',
        name='procesador_senal'
    )

    rqt = Node(
        package='rqt_plot',
        executable='rqt_plot',
        name='rqt_plot',
        arguments=[
            '/proc_signal/data/data',
            '/signal/data/data'
            
        ]
    )

    return LaunchDescription([
        generador,
        procesador,
        rqt
    ])
