import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np


class Controller(Node):

    def __init__(self):
        super().__init__('ctrl')

        # Publisher  señal de control
        self.pub_u = self.create_publisher(Float32, '/motor_input_u', 10)

        # Subscribers
        self.sub_y = self.create_subscription(
            Float32,
            '/motor_speed_y',
            self.callback_y,
            10
        )

        self.sub_sp = self.create_subscription(
            Float32,
            '/set_point',
            self.callback_sp,
            10
        )

        # Variables
        self.y = 0.0
        self.sp = 0.0

        # Ganancia P 
        self.Kp = 0.3
        self.Ki=0.1
        self.error_sum=0.0

        # Timer      frecuencia de control
        self.timer = self.create_timer(0.01, self.control_loop)

        self.get_logger().info('Controller Node Started ')

    def callback_y(self, msg):
        self.y = msg.data

    def callback_sp(self, msg):
        self.sp = msg.data

    def control_loop(self):

        # Error
        error = self.sp - self.y
        self.error_sum += error
        self.error_sum = np.clip(self.error_sum, -100.0, 100.0)

        # Controlador PI    
        u = self.Kp * error + self.Ki * self.error_sum

        # Publicar
        msg = Float32()
        msg.data = float(u)
        self.pub_u.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = Controller()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()