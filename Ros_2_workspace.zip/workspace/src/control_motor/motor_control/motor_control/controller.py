import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from rcl_interfaces.msg import SetParametersResult
import numpy as np


class Controller(Node):

    def __init__(self):
        super().__init__('ctrl')

        self.declare_parameter('Kp', 0.5)
        self.declare_parameter('Ki', 0.1)

        # Get Parameters
        self.Kp = self.get_parameter('Kp').value
        self.Ki = self.get_parameter('Ki').value


        self.y = 0.0
        self.sp = 0.0
        self.error_sum = 0.0

        # Publisher
        self.pub_u = self.create_publisher(Float32, 'motor_input_u', 10)

        # Subscribers

        self.sub_y = self.create_subscription(
            Float32,
            'motor_speed_y',
            self.callback_y,
            10
        )

        self.sub_sp = self.create_subscription(
            Float32,
            'set_point',
            self.callback_sp,
            10
        )

        
        # Timer (loop de control)
        self.sample_time = 0.01  # igual que motor_sys
        self.timer = self.create_timer(self.sample_time, self.control_loop)

        # Parameter Callback
        self.add_on_set_parameters_callback(self.parameters_callback)

        self.get_logger().info('Controller Node Started ')

    # Callbacks
    def callback_y(self, msg):
        self.y = msg.data

    def callback_sp(self, msg):
        self.sp = msg.data

    # Control Loop
    def control_loop(self):

        # Error
        error = self.sp - self.y

        # Integral (acumulación)
        self.error_sum += error

        # Anti-windup
        self.error_sum = np.clip(self.error_sum, -100.0, 100.0)

        # Control PI
        u = self.Kp * error + self.Ki * self.error_sum

        # Publicar señal de control
        msg = Float32()
        msg.data = float(u)
        self.pub_u.publish(msg)

    # Parameter validation
    def parameters_callback(self, params):

        for param in params:

            if param.name == "Kp":
                if param.value < 0.0:
                    self.get_logger().warn("Invalid Kp! Cannot be negative.")
                    return SetParametersResult(successful=False, reason="Kp < 0")
                else:
                    self.Kp = param.value
                    self.get_logger().info(f"Kp updated to {self.Kp}")

            if param.name == "Ki":
                if param.value < 0.0:
                    self.get_logger().warn("Invalid Ki! Cannot be negative.")
                    return SetParametersResult(successful=False, reason="Ki < 0")
                else:
                    self.Ki = param.value
                    self.get_logger().info(f"Ki updated to {self.Ki}")

        return SetParametersResult(successful=True)


# Main
def main(args=None):
    rclpy.init(args=args)

    node = Controller()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
