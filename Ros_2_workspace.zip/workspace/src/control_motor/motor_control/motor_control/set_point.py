# Imports
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from rcl_interfaces.msg import SetParametersResult
import numpy as np


class SetPoint(Node):

    def __init__(self):
        super().__init__('sp_gen')

        # =========================
        # Declarar parámetros
        # =========================
        self.declare_parameter('signal_type', 'sine')   # sine / square
        self.declare_parameter('amplitude', 5.0)
        self.declare_parameter('frequency', 0.5)

        # Obtener parámetros
        self.signal_type = self.get_parameter('signal_type').value
        self.amplitude = self.get_parameter('amplitude').value
        self.frequency = self.get_parameter('frequency').value

        # Variables internas
        self.t = 0.0
        self.sample_time = 0.01

        # Publisher
        self.pub_sp = self.create_publisher(Float32, 'set_point', 10)

        # Timer
        self.timer = self.create_timer(self.sample_time, self.timer_cb)

        # Callback de parámetros
        self.add_on_set_parameters_callback(self.parameters_callback)

        self.get_logger().info('SetPoint Node Started ')

    # =========================
    # Timer callback
    # =========================
    def timer_cb(self):

        # Señal sinusoidal
        if self.signal_type == 'sine':
            sp = self.amplitude * np.sin(2 * np.pi * self.frequency * self.t)

        # Señal cuadrada
        elif self.signal_type == 'square':
            sp = self.amplitude * np.sign(
                np.sin(2 * np.pi * self.frequency * self.t)
            )

        else:
            sp = 0.0

        # Publicar
        msg = Float32()
        msg.data = float(sp)
        self.pub_sp.publish(msg)

        # Incrementar tiempo
        self.t += self.sample_time

    # =========================
    # Callback de parámetros
    # =========================
    def parameters_callback(self, params):

        for param in params:

            if param.name == "signal_type":
                if param.value not in ['sine', 'square']:
                    self.get_logger().warn("Invalid signal_type!")
                    return SetParametersResult(successful=False)
                self.signal_type = param.value
                self.get_logger().info(f"Signal type: {self.signal_type}")

            if param.name == "amplitude":
                self.amplitude = param.value
                self.get_logger().info(f"Amplitude: {self.amplitude}")

            if param.name == "frequency":
                self.frequency = param.value
                self.get_logger().info(f"Frequency: {self.frequency}")

        return SetParametersResult(successful=True)


def main(args=None):
    rclpy.init(args=args)
    node = SetPoint()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
